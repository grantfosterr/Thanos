# Thanos is on Discord now!!!

## Note

Any public link to add the bot (at least from me) is dead. You have to sel-host the bot yourself.

## Important warning

This bot has the ability to let ANYONE with ADMIN or BAN USERS permission BAN anyone on the server! Use caution when using this, or don't use it at all!

OTHER WARNING: This bot ALSO has the ability to ban RANDOM USERS! Once again, use at your own risk!!!

Due to Discord API limits, this bot will not ban anyone who is admin, or anyone with a higher role than the bot's highest role.

## How to use
0. You have to move the ThanosBot role in server settings above all roles that you would like Thanos to balance, otherwise he won't have the power to do so.
Summon Thanos by calling him. Type his name before your message ("Thanos " + command (listed below))

__Thanos can:__

* **ban**: just specify whomst you want to ban and he will bring balance at your request. You can have one or more persons listed. You can also use "Thanos" or "me" as a person.
* **spare**: specify whomst you want to spare and he will say they are spared. However their fate may change... (aka they can still get banned) Again you can list one or more persons.
* **snap**: Thanos will snap his fingers to bring instant balance to the number of users on your server (excluding admins and bots I think)

### Building

Requires nodejs

After getting nodejs and setting up npm and all, retrieve the code, then cd into the folder containing the code, then run: 
`npm install`

Then set up `config.json` as needed

Then `node app.js` or `npm start` if I'm correct...
